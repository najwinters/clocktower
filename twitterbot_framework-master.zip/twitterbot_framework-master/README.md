# twitterbot_framework

A basic framework for creating Twitter bots using Python 3 and [tweepy](http://www.tweepy.org). This goes along with my [tutorial](http://blog.mollywhite.net/twitter-bots-pt2/) on creating Twitter bots.
